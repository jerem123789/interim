import Fastify from "fastify";
import cors from "@fastify/cors";
import { z } from "zod";
import { scoreCandidate, CandidateForm } from "@interim/shared";

const app = Fastify({ logger: true });

await app.register(cors, { origin: true });

const CandidateSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email(),
  phone: z.string().min(6),
  city: z.string().min(1),
  distanceKm: z.number().min(0),
  availability: z.enum(["immediate", "2weeks", "1month", "later"]),
  experienceYears: z.number().min(0),
  hasVehicle: z.boolean(),
  licenses: z.array(z.string()),
  certifications: z.array(z.string()),
  languages: z.array(z.string()),
  desiredRate: z.number().min(0),
  notes: z.string().optional()
});

const applications: Array<{
  id: string;
  createdAt: string;
  form: CandidateForm;
  score: number;
  status: string;
}> = [];

const missions = [
  {
    id: "m1",
    title: "Cariste CACES 3",
    city: "Lyon",
    requiredLicenses: ["CACES 3"],
    minExperience: 1
  },
  {
    id: "m2",
    title: "Manutentionnaire",
    city: "Marseille",
    requiredLicenses: [],
    minExperience: 0
  }
];

app.get("/health", async () => ({ status: "ok" }));

app.post("/score", async (req, res) => {
  const parsed = CandidateSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).send({ error: parsed.error.flatten() });
  }
  const result = scoreCandidate(parsed.data);
  return { ...result };
});

app.post("/applications", async (req, res) => {
  const parsed = CandidateSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).send({ error: parsed.error.flatten() });
  }
  const result = scoreCandidate(parsed.data);
  const entry = {
    id: `app_${applications.length + 1}`,
    createdAt: new Date().toISOString(),
    form: parsed.data,
    score: result.score,
    status: result.status
  };
  applications.unshift(entry);
  return entry;
});

app.get("/applications", async () => applications);

app.get("/missions", async () => missions);

app.post("/match", async (req, res) => {
  const parsed = CandidateSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).send({ error: parsed.error.flatten() });
  }
  const candidate = parsed.data;
  const matches = missions.map((m) => {
    const licenseMatch = m.requiredLicenses.every((l) =>
      candidate.licenses.map((x) => x.toLowerCase()).includes(l.toLowerCase())
    );
    const experienceMatch = candidate.experienceYears >= m.minExperience;
    return {
      missionId: m.id,
      title: m.title,
      city: m.city,
      fitScore: (licenseMatch ? 60 : 20) + (experienceMatch ? 40 : 10)
    };
  });
  return matches.sort((a, b) => b.fitScore - a.fitScore);
});

const port = Number(process.env.PORT || 4000);
app.listen({ port, host: "0.0.0.0" });
