export type Availability = "immediate" | "2weeks" | "1month" | "later";

export type CandidateForm = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  city: string;
  distanceKm: number;
  availability: Availability;
  experienceYears: number;
  hasVehicle: boolean;
  licenses: string[];
  certifications: string[];
  languages: string[];
  desiredRate: number;
  notes?: string;
};

export type ScoreResult = {
  score: number;
  status: "A recontacter" | "A verifier" | "Non prioritaire";
  reasons: string[];
};

export const scoreCandidate = (form: CandidateForm): ScoreResult => {
  let score = 0;
  const reasons: string[] = [];

  // Experience
  const expPoints = Math.min(Math.max(form.experienceYears, 0), 5) * 5;
  score += expPoints;
  if (expPoints >= 15) reasons.push("Experience solide");

  // Availability
  if (form.availability === "immediate") {
    score += 20;
    reasons.push("Disponible immediatement");
  } else if (form.availability === "2weeks") {
    score += 10;
  } else if (form.availability === "1month") {
    score += 5;
  }

  // Mobility
  if (form.hasVehicle) {
    score += 10;
    reasons.push("Mobilite (vehicule)");
  }

  if (form.distanceKm <= 10) {
    score += 10;
  } else if (form.distanceKm <= 20) {
    score += 5;
  }

  // Licenses & certifications
  const licensePoints = Math.min(form.licenses.length * 5, 15);
  score += licensePoints;
  if (licensePoints >= 10) reasons.push("Permis/qualifs utiles");

  const certPoints = Math.min(form.certifications.length * 5, 15);
  score += certPoints;

  // Languages
  if (form.languages.map((l) => l.toLowerCase()).includes("francais")) {
    score += 5;
  }

  // Rate alignment (simple heuristic)
  if (form.desiredRate <= 15) score += 5;
  if (form.desiredRate <= 12) score += 5;

  if (score > 100) score = 100;

  let status: ScoreResult["status"] = "Non prioritaire";
  if (score >= 70) status = "A recontacter";
  else if (score >= 50) status = "A verifier";

  return { score, status, reasons };
};
