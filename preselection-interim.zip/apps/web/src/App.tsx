import { useEffect, useState } from "react";
import "./styles.css";
import type { CandidateForm, ScoreResult } from "@interim/shared";

const API_URL = "http://localhost:4000";

const emptyForm: CandidateForm = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  city: "",
  distanceKm: 0,
  availability: "immediate",
  experienceYears: 0,
  hasVehicle: false,
  licenses: [],
  certifications: [],
  languages: ["Francais"],
  desiredRate: 12,
  notes: ""
};

const parseList = (value: string) =>
  value
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

export default function App() {
  const [tab, setTab] = useState<"candidat" | "recruteur">("candidat");
  const [form, setForm] = useState<CandidateForm>(emptyForm);
  const [score, setScore] = useState<ScoreResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [applications, setApplications] = useState<any[]>([]);

  const loadApplications = async () => {
    const res = await fetch(`${API_URL}/applications`);
    const data = await res.json();
    setApplications(data);
  };

  useEffect(() => {
    if (tab === "recruteur") loadApplications();
  }, [tab]);

  const submit = async () => {
    setLoading(true);
    const res = await fetch(`${API_URL}/applications`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setScore({ score: data.score, status: data.status, reasons: [] });
    setLoading(false);
  };

  const getScore = async () => {
    const res = await fetch(`${API_URL}/score`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setScore(data);
  };

  return (
    <div>
      <header>
        <h1>Preselection Interim</h1>
        <p>App web & mobile pour qualifier rapidement les candidatures.</p>
      </header>

      <div className="container">
        <div className="tabs">
          <button
            className={`tab ${tab === "candidat" ? "active" : ""}`}
            onClick={() => setTab("candidat")}
          >
            Espace candidat
          </button>
          <button
            className={`tab ${tab === "recruteur" ? "active" : ""}`}
            onClick={() => setTab("recruteur")}
          >
            Espace recruteur
          </button>
        </div>

        {tab === "candidat" && (
          <div className="grid">
            <div className="card">
              <h3>Formulaire candidat</h3>
              <div className="row">
                <div>
                  <label>Prenom</label>
                  <input
                    value={form.firstName}
                    onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  />
                </div>
                <div>
                  <label>Nom</label>
                  <input
                    value={form.lastName}
                    onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                  />
                </div>
              </div>
              <div className="row">
                <div>
                  <label>Email</label>
                  <input
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                  />
                </div>
                <div>
                  <label>Telephone</label>
                  <input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
              </div>
              <div className="row">
                <div>
                  <label>Ville</label>
                  <input
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                  />
                </div>
                <div>
                  <label>Distance (km)</label>
                  <input
                    type="number"
                    value={form.distanceKm}
                    onChange={(e) =>
                      setForm({ ...form, distanceKm: Number(e.target.value) })
                    }
                  />
                </div>
              </div>
              <div className="row">
                <div>
                  <label>Disponibilite</label>
                  <select
                    value={form.availability}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        availability: e.target.value as CandidateForm["availability"]
                      })
                    }
                  >
                    <option value="immediate">Immediat</option>
                    <option value="2weeks">Sous 2 semaines</option>
                    <option value="1month">Sous 1 mois</option>
                    <option value="later">Plus tard</option>
                  </select>
                </div>
                <div>
                  <label>Experience (annees)</label>
                  <input
                    type="number"
                    value={form.experienceYears}
                    onChange={(e) =>
                      setForm({ ...form, experienceYears: Number(e.target.value) })
                    }
                  />
                </div>
              </div>
              <div className="row">
                <div>
                  <label>Vehicule</label>
                  <select
                    value={form.hasVehicle ? "oui" : "non"}
                    onChange={(e) =>
                      setForm({ ...form, hasVehicle: e.target.value === "oui" })
                    }
                  >
                    <option value="oui">Oui</option>
                    <option value="non">Non</option>
                  </select>
                </div>
                <div>
                  <label>Taux horaire souhaite</label>
                  <input
                    type="number"
                    value={form.desiredRate}
                    onChange={(e) =>
                      setForm({ ...form, desiredRate: Number(e.target.value) })
                    }
                  />
                </div>
              </div>
              <label>Permis (separes par virgule)</label>
              <input
                value={form.licenses.join(", ")}
                onChange={(e) => setForm({ ...form, licenses: parseList(e.target.value) })}
              />
              <label>Certifications (separees par virgule)</label>
              <input
                value={form.certifications.join(", ")}
                onChange={(e) =>
                  setForm({ ...form, certifications: parseList(e.target.value) })
                }
              />
              <label>Langues (separees par virgule)</label>
              <input
                value={form.languages.join(", ")}
                onChange={(e) => setForm({ ...form, languages: parseList(e.target.value) })}
              />
              <label>Notes</label>
              <textarea
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
              <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                <button onClick={getScore}>Evaluer</button>
                <button className="secondary" onClick={submit} disabled={loading}>
                  {loading ? "Envoi..." : "Soumettre"}
                </button>
              </div>
            </div>

            <div className="card">
              <h3>Resultat de preselection</h3>
              {score ? (
                <div>
                  <p>
                    <strong>Score:</strong> {score.score}/100
                  </p>
                  <p>
                    <strong>Statut:</strong> {score.status}
                  </p>
                  {score.reasons?.length > 0 && (
                    <div style={{ marginTop: 8 }}>
                      {score.reasons.map((r) => (
                        <span key={r} className="badge" style={{ marginRight: 6 }}>
                          {r}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <p>Remplissez le formulaire pour obtenir un score.</p>
              )}
            </div>
          </div>
        )}

        {tab === "recruteur" && (
          <div className="grid">
            <div className="card">
              <h3>Tableau de bord</h3>
              <p>Dernieres candidatures recues</p>
              <div className="list" style={{ marginTop: 12 }}>
                {applications.length === 0 && <p>Aucune candidature</p>}
                {applications.map((a) => (
                  <div key={a.id} className="card" style={{ padding: 12 }}>
                    <strong>
                      {a.form.firstName} {a.form.lastName}
                    </strong>
                    <div className="row" style={{ marginTop: 8 }}>
                      <div>Score: {a.score}</div>
                      <div>Status: {a.status}</div>
                    </div>
                    <div style={{ marginTop: 8, color: "#555" }}>
                      {a.form.city} · {a.form.experienceYears} ans · {a.form.hasVehicle ? "Vehicule" : "Sans vehicule"}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <h3>Actions rapides</h3>
              <button onClick={loadApplications}>Rafraichir</button>
              <p style={{ marginTop: 12 }}>
                Export PDF/Excel et gestion missions seront branches sur la prochaine iteration.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
